﻿/*
    _                _      _  ____   _                           _____
   / \    _ __  ___ | |__  (_)/ ___| | |_  ___   __ _  _ __ ___  |  ___|__ _  _ __  _ __ ___
  / _ \  | '__|/ __|| '_ \ | |\___ \ | __|/ _ \ / _` || '_ ` _ \ | |_  / _` || '__|| '_ ` _ \
 / ___ \ | |  | (__ | | | || | ___) || |_|  __/| (_| || | | | | ||  _|| (_| || |   | | | | | |
/_/   \_\|_|   \___||_| |_||_||____/  \__|\___| \__,_||_| |_| |_||_|   \__,_||_|   |_| |_| |_|

 Copyright 2015-2016 Florian "KlappPC" Lang
 Contact: ichhoeremusik@gmx.net

 Licensed under the Apache License, Version 2.0 (the "License");
 you may not use this file except in compliance with the License.
 You may obtain a copy of the License at

 http://www.apache.org/licenses/LICENSE-2.0
					
 Unless required by applicable law or agreed to in writing, software
 distributed under the License is distributed on an "AS IS" BASIS,
 WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 See the License for the specific language governing permissions and
 limitations under the License.

*/
using System;
using System.Windows.Forms;

namespace GUI {
	/**
     * popup Message when Input is required
     */
	public partial class Form2 : Form {
		ServerProcess proc;
		public Form2(ServerProcess proc, string msg) {
			this.proc = proc;
			InitializeComponent();
			label1.Text = msg;
			button1.DialogResult = DialogResult.OK;
		}

		private void button1_Click(object sender, EventArgs e) {
			proc.Write(textBox1.Text);
		}
	}
}
